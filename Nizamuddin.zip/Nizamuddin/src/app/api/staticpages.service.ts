import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class StaticpagesService {
  private apiUrl = 'https://netnovaz.com/nizamuddin-app/apis/articles.json';
  private photoGallery = 'http://netnovaz.com/nizamuddin-app/apis/photo-gallery.json';
  constructor(private http: HttpClient) { }

  getArticles() {
    return this.http.get(this.apiUrl);
  }
}
