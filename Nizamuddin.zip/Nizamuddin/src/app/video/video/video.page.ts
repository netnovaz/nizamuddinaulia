import { Component, OnInit } from '@angular/core';
import { LoadingController } from '@ionic/angular';
import { finalize } from 'rxjs/operators';

import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { YoutubeVideoPlayer } from '@ionic-native/youtube-video-player/ngx';
@Component({
  selector: 'app-video',
  templateUrl: './video.page.html',
  styleUrls: ['./video.page.scss'],
})
export class VideoPage implements OnInit {
  loading: any;
  playlists: string;
  error: string;
  apiKey = 'AIzaSyBMDn2bNTaLTbL8JHMjZQRpM5BQ0u3jKj4';
  apiUrl = 'https://www.googleapis.com/youtube/v3/';
  channelId = 'UCJswHD4PkJnq3KerqkYSHzw'; // Devdactic Channel ID
  constructor(private http: HttpClient, public loadingController: LoadingController, private youtube: YoutubeVideoPlayer) {
    this.playlists = '';
    this.error = '';
    
  }

  ngOnInit() {

  }
  async ionViewWillEnter() {
    // Present a loading controller until the data is loaded
    await this.presentLoading();
    // Load the data
    this.getPlaylistsForChannel()
        .pipe(
            finalize(async () => {
              // Hide the loading spinner on success or error
              await this.loading.dismiss();
            })
        )
        .subscribe(
            result => {
              // Set the data to display in the template
              this.playlists = result['items'];
            },
            err => {
              // Set the error information to display in the template
              this.error = `An error occurred, the data could not be retrieved: Status: ${err.status}, Message: ${err.statusText}`;
            }
        );
  }

  async presentLoading() {
    // Prepare a loading controller
    this.loading = await this.loadingController.create({
      message: 'Loading...'
    });
    // Present the loading controller
    await this.loading.present();
  }

  getPlaylistsForChannel() {
    return this.http.get(this.apiUrl+'playlists?key=' + this.apiKey + '&channelId=' + this.channelId + '&part=snippet,id&maxResults=20');
  }
 
  getListVideos(listId) {
    return this.http.get(this.apiUrl+'playlistItems?key=' + this.apiKey + '&playlistId=' + listId +'&part=snippet,id&maxResults=20');
  }


  openYtVideo(myvideoid) {
    this.youtube.openVideo(myvideoid);
  }
}
