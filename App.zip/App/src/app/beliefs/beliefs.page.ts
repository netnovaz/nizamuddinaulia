import { Component, OnInit } from "@angular/core";
@Component({
  selector: "app-beliefs",
  templateUrl: "./beliefs.page.html",
  styleUrls: ["./beliefs.page.scss"],
})
export class BeliefsPage implements OnInit {
  loading: any;
  dataItem: string;
  error: string;

  constructor() {}

  ngOnInit() {}
}
