import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    loadChildren: './home/home.module#HomePageModule'
  },
  {
    path: 'welcome',
    loadChildren: './welcome/welcome.module#WelcomePageModule'
  },
  {
    path: 'hazratamirkhusrau',
    loadChildren: './hazrat-amir-khusrau/hazrat-amir-khusrau.module#HazratAmirKhusrauPageModule'
  },
  {
    path: 'islamandsufism',
    loadChildren: './islam-and-sufism/islam-and-sufism.module#IslamAndSufismPageModule'
  },
  {
    path: 'beliefs',
    loadChildren: './beliefs/beliefs.module#BeliefsPageModule'
  },
  {
    path: 'shajrah',
    loadChildren: './shajrah/shajrah.module#ShajrahPageModule'
  },
  {
    path: 'donation',
    loadChildren: './donation/donation.module#DonationPageModule'
  },
  {
    path: 'offerings',
    loadChildren: './offerings/offerings.module#OfferingsPageModule'
  },
  {
    path: 'projects',
    loadChildren: './projects/projects.module#ProjectsPageModule'
  },
  {
    path: 'photos',
    loadChildren: './photos/photos.module#PhotosPageModule'
  },
  {
    path: 'contactus',
    loadChildren: './contactus/contactus.module#ContactusPageModule'
  }  
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
