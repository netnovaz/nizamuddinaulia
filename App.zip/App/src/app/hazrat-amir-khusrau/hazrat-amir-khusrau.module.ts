import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { HazratAmirKhusrauPage } from './hazrat-amir-khusrau.page';

const routes: Routes = [
  {
    path: '',
    component: HazratAmirKhusrauPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [HazratAmirKhusrauPage]
})
export class HazratAmirKhusrauPageModule {}
