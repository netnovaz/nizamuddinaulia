import { Component, OnInit } from "@angular/core";
@Component({
  selector: "app-hazrat-amir-khusrau",
  templateUrl: "./hazrat-amir-khusrau.page.html",
  styleUrls: ["./hazrat-amir-khusrau.page.scss"],
})
export class HazratAmirKhusrauPage implements OnInit {
  constructor() {}

  ngOnInit() {}
}
