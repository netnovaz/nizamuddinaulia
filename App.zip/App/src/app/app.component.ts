import { Component } from '@angular/core';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {
 
  public appPages = [
    { title: 'Home',  url: '/home', icon: 'home' },
    { title: 'Hazrat Nizamuddin Aulia (R.A.)', url: '/welcome', icon: 'book' },
    { title: 'Hazrat Amir Khusrau (R.A.)', url: '/hazratamirkhusrau', icon: 'book' },
    { title: 'Islam & Sufism',url: '/islamandsufism', icon: 'book' },
    { title: 'Beliefs',url: '/beliefs', icon: 'book' },
    { title: 'Shajrah (Spiritual Chain)',url: '/shajrah', icon: 'book' },
    { title: 'Online Offerings', url: '/offerings', icon: 'book' },
    { title: 'Donation', url: '/donation', icon: 'book' },
    { title: 'Projects', url: '/projects', icon: 'book' },
    { title: 'Photos',url: '/photos', icon: 'book' },
    { title: 'Contact', url: '/contactus', icon: 'phone' },
  ];


  public adminPages = [
    { src : "images/icons/user-menu-web-icon.png", alt: "web icon", title:"Visit Our Website" , url: "http://nizamuddinaulia.org/" },
    { src : "images/icons/book-pdf-icon.png", alt: "Books and PDF", title:"Recitation Wazifa" , url: "http://netnovaz.com/nizamuddin-app/books-and-pdf/Wazifa.pdf" },
    { src : "images/icons/user-menu-fb-icon.png", alt:"fb icon", title:"Like Us on Facebook", url: "https://www.facebook.com/dargahnizamuddinaulia/"},
    { src : "images/icons/user-menu-tw-icon.png", alt:"twitter icon", title:"Follow us on Twitter", url: "https://twitter.com/sufi_centre"},
    { src : "images/icons/user-menu-insta-icon.png", alt:"instagram Icon", title:"Follow us on Instagram", url: "https://www.instagram.com/dargahnizamuddinaulia/"},
    { src : "images/icons/user-menu-yt-icon.png", alt:"youtube icon", title:"Subscribe us on Youtube", url: "https://www.youtube.com/channel/UCreOlP89ZAOCe-micSrA5qA"}              
  ]

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }


}
