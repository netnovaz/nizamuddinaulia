(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/home/home.page.html":
/*!***************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/home/home.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!--<ion-header>\n \n</ion-header>-->\n\n<ion-content>\n  <!--<ion-card class=\"welcome-card\">\n    <ion-img src=\"/assets/shapes.svg\"></ion-img>\n    <ion-card-header>\n      <ion-card-subtitle>Get Started</ion-card-subtitle>\n      <ion-card-title>Welcome to Ionic</ion-card-title>\n    </ion-card-header>\n    <ion-card-content>\n      <p>Now that your app has been created, you'll want to start building out features and components. Check out some\n        of the resources below for next steps.</p>\n    </ion-card-content>\n  </ion-card>\n  <ion-list lines=\"none\">\n    <ion-list-header>\n      <ion-label>Resources</ion-label>\n    </ion-list-header>\n    <ion-item href=\"https://ionicframework.com/docs/\">\n      <ion-icon slot=\"start\" color=\"medium\" name=\"book\"></ion-icon>\n      <ion-label>Ionic Documentation</ion-label>\n    </ion-item>\n    <ion-item href=\"https://ionicframework.com/docs/building/scaffolding\">\n      <ion-icon slot=\"start\" color=\"medium\" name=\"build\"></ion-icon>\n      <ion-label>Scaffold Out Your App</ion-label>\n    </ion-item>\n    <ion-item href=\"https://ionicframework.com/docs/layout/structure\">\n      <ion-icon slot=\"start\" color=\"medium\" name=\"grid\"></ion-icon>\n      <ion-label>Change Your App Layout</ion-label>\n    </ion-item>\n    <ion-item href=\"https://ionicframework.com/docs/theming/basics\">\n      <ion-icon slot=\"start\" color=\"medium\" name=\"color-fill\"></ion-icon>\n      <ion-label>Theme Your App</ion-label>\n    </ion-item>\n  </ion-list>-->\n  <div id=\"homepage\">\n  <ion-toolbar class=\"productHeader nav-bottom\" >\n\n    <ion-buttons slot=\"start\" class=\"ion-padding-bottom ion-padding-start\">\n      <ion-menu-button menu=\"pages\" autohide=\"false\">\n        <img src=\"http://netnovaz.com/nizamuddin-app/images/main-menu-icon.png\" alt=\"right-menu\" />\n      </ion-menu-button>\n    </ion-buttons>\n\n    <ion-buttons slot=\"end\" class=\"ion-padding-bottom ion-padding-end\">\n      <ion-menu-button menu=\"admin\" autohide=\"false\">\n        <img src=\"http://netnovaz.com/nizamuddin-app/images/user-menu-icon.png\" alt=\"right-menu\" /> \n      </ion-menu-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n  </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/home/home.module.ts":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");







let HomePageModule = class HomePageModule {
};
HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]
                }
            ])
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
    })
], HomePageModule);



/***/ }),

/***/ "./src/app/home/home.page.scss":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".welcome-card ion-img {\n  overflow: hidden;\n}\n\n.menu-bg-color {\n  min-height: 81px;\n  background: url(http://netnovaz.com/nizamuddin-app/images/menu-bg-img.png) no-repeat left top, radial-gradient(#efb538, #e89116);\n  background-size: 100% 80px;\n  padding-left: 0;\n}\n\n:host {\n  --ion-item-background: transparent !important;\n}\n\n.nav-bottom {\n  position: absolute;\n  bottom: 20px;\n  left: 0;\n}\n\n.productHeader {\n  --background: transparent;\n}\n\n#homepage {\n  background: url('bg-frm-btm.png') center bottom no-repeat, url('bg-frm-top.png') center top no-repeat;\n  background-color: transparent;\n  background-image: url('bg-frm-btm.png'), url('bg-frm-top.png');\n  background-repeat: no-repeat, no-repeat;\n  background-attachment: scroll, scroll;\n  background-clip: border-box, border-box;\n  background-origin: padding-box, padding-box;\n  background-position-x: center, center;\n  background-position-y: bottom, top;\n  background-size: auto auto, auto auto;\n  background-size: cover;\n  width: 100%;\n  height: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9DOlxcUHJvamVjdFxcSW9uaWNcXG5pemFtdWRkaW5hcHAvc3JjXFxhcHBcXGhvbWVcXGhvbWUucGFnZS5zY3NzIiwic3JjL2FwcC9ob21lL2hvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7QUNDRjs7QURFQTtFQUNFLGdCQUFBO0VBQ0EsZ0lBQUE7RUFDQSwwQkFBQTtFQUNBLGVBQUE7QUNDRjs7QURJQTtFQUNFLDZDQUFBO0FDREY7O0FESUE7RUFDRSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxPQUFBO0FDREY7O0FESUE7RUFDRSx5QkFBQTtBQ0RGOztBRElBO0VBQ00scUdBQUE7RUFDQSw2QkFBQTtFQUNBLDhEQUFBO0VBQ0EsdUNBQUE7RUFDQSxxQ0FBQTtFQUNBLHVDQUFBO0VBQ0EsMkNBQUE7RUFDQSxxQ0FBQTtFQUNBLGtDQUFBO0VBQ0EscUNBQUE7RUFDQSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDRE4iLCJmaWxlIjoic3JjL2FwcC9ob21lL2hvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLndlbGNvbWUtY2FyZCBpb24taW1nIHtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLm1lbnUtYmctY29sb3Ige1xuICBtaW4taGVpZ2h0OiA4MXB4O1xuICBiYWNrZ3JvdW5kOiB1cmwoaHR0cDovL25ldG5vdmF6LmNvbS9uaXphbXVkZGluLWFwcC9pbWFnZXMvbWVudS1iZy1pbWcucG5nKSBuby1yZXBlYXQgbGVmdCB0b3AsIHJhZGlhbC1ncmFkaWVudCgjZWZiNTM4LCAjZTg5MTE2KTtcbiAgYmFja2dyb3VuZC1zaXplOiAxMDAlIDgwcHg7XG4gIHBhZGRpbmctbGVmdDogMDtcblxuXG5cbn1cbjpob3N0IHtcbiAgLS1pb24taXRlbS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xufVxuXG4ubmF2LWJvdHRvbSB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiAyMHB4O1xuICBsZWZ0OiAwO1xufVxuXG4ucHJvZHVjdEhlYWRlciB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG59XG5cbiNob21lcGFnZSB7XG4gICAgICBiYWNrZ3JvdW5kOiB1cmwoLi4vLi4vYXNzZXRzL2ltZ3MvYmctZnJtLWJ0bS5wbmcpIGNlbnRlciBib3R0b20gbm8tcmVwZWF0LCB1cmwoLi4vLi4vYXNzZXRzL2ltZ3MvYmctZnJtLXRvcC5wbmcpIGNlbnRlciB0b3Agbm8tcmVwZWF0O1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuLi8uLi9hc3NldHMvaW1ncy9iZy1mcm0tYnRtLnBuZ1wiKSwgdXJsKFwiLi4vLi4vYXNzZXRzL2ltZ3MvYmctZnJtLXRvcC5wbmdcIik7XG4gICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0LCBuby1yZXBlYXQ7XG4gICAgICBiYWNrZ3JvdW5kLWF0dGFjaG1lbnQ6IHNjcm9sbCwgc2Nyb2xsO1xuICAgICAgYmFja2dyb3VuZC1jbGlwOiBib3JkZXItYm94LCBib3JkZXItYm94O1xuICAgICAgYmFja2dyb3VuZC1vcmlnaW46IHBhZGRpbmctYm94LCBwYWRkaW5nLWJveDtcbiAgICAgIGJhY2tncm91bmQtcG9zaXRpb24teDogY2VudGVyLCBjZW50ZXI7XG4gICAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uLXk6IGJvdHRvbSwgdG9wO1xuICAgICAgYmFja2dyb3VuZC1zaXplOiBhdXRvIGF1dG8sIGF1dG8gYXV0bztcbiAgICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gICAgICB3aWR0aDogMTAwJTtcbiAgICAgIGhlaWdodDogMTAwJTtcbn1cblxuIiwiLndlbGNvbWUtY2FyZCBpb24taW1nIHtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLm1lbnUtYmctY29sb3Ige1xuICBtaW4taGVpZ2h0OiA4MXB4O1xuICBiYWNrZ3JvdW5kOiB1cmwoaHR0cDovL25ldG5vdmF6LmNvbS9uaXphbXVkZGluLWFwcC9pbWFnZXMvbWVudS1iZy1pbWcucG5nKSBuby1yZXBlYXQgbGVmdCB0b3AsIHJhZGlhbC1ncmFkaWVudCgjZWZiNTM4LCAjZTg5MTE2KTtcbiAgYmFja2dyb3VuZC1zaXplOiAxMDAlIDgwcHg7XG4gIHBhZGRpbmctbGVmdDogMDtcbn1cblxuOmhvc3Qge1xuICAtLWlvbi1pdGVtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG59XG5cbi5uYXYtYm90dG9tIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IDIwcHg7XG4gIGxlZnQ6IDA7XG59XG5cbi5wcm9kdWN0SGVhZGVyIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cblxuI2hvbWVwYWdlIHtcbiAgYmFja2dyb3VuZDogdXJsKC4uLy4uL2Fzc2V0cy9pbWdzL2JnLWZybS1idG0ucG5nKSBjZW50ZXIgYm90dG9tIG5vLXJlcGVhdCwgdXJsKC4uLy4uL2Fzc2V0cy9pbWdzL2JnLWZybS10b3AucG5nKSBjZW50ZXIgdG9wIG5vLXJlcGVhdDtcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi4uLy4uL2Fzc2V0cy9pbWdzL2JnLWZybS1idG0ucG5nXCIpLCB1cmwoXCIuLi8uLi9hc3NldHMvaW1ncy9iZy1mcm0tdG9wLnBuZ1wiKTtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdCwgbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLWF0dGFjaG1lbnQ6IHNjcm9sbCwgc2Nyb2xsO1xuICBiYWNrZ3JvdW5kLWNsaXA6IGJvcmRlci1ib3gsIGJvcmRlci1ib3g7XG4gIGJhY2tncm91bmQtb3JpZ2luOiBwYWRkaW5nLWJveCwgcGFkZGluZy1ib3g7XG4gIGJhY2tncm91bmQtcG9zaXRpb24teDogY2VudGVyLCBjZW50ZXI7XG4gIGJhY2tncm91bmQtcG9zaXRpb24teTogYm90dG9tLCB0b3A7XG4gIGJhY2tncm91bmQtc2l6ZTogYXV0byBhdXRvLCBhdXRvIGF1dG87XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG59Il19 */"

/***/ }),

/***/ "./src/app/home/home.page.ts":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let HomePage = class HomePage {
};
HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: __webpack_require__(/*! raw-loader!./home.page.html */ "./node_modules/raw-loader/index.js!./src/app/home/home.page.html"),
        styles: [__webpack_require__(/*! ./home.page.scss */ "./src/app/home/home.page.scss")]
    })
], HomePage);



/***/ })

}]);
//# sourceMappingURL=home-home-module-es2015.js.map