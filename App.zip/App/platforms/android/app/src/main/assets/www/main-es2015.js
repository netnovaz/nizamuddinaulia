(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./home/home.module": [
		"./src/app/home/home.module.ts",
		"home-home-module"
	],
	"./list/list.module": [
		"./src/app/list/list.module.ts",
		"list-list-module"
	],
	"./login/login.module": [
		"./src/app/login/login.module.ts",
		"login-login-module"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return __webpack_require__.e(ids[1]).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet-controller_8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-action-sheet-controller_8.entry.js",
		"common",
		0
	],
	"./ion-action-sheet-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-action-sheet-ios.entry.js",
		"common",
		1
	],
	"./ion-action-sheet-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-action-sheet-md.entry.js",
		"common",
		2
	],
	"./ion-alert-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-alert-ios.entry.js",
		"common",
		3
	],
	"./ion-alert-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-alert-md.entry.js",
		"common",
		4
	],
	"./ion-app_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-app_8-ios.entry.js",
		"common",
		5
	],
	"./ion-app_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-app_8-md.entry.js",
		"common",
		6
	],
	"./ion-avatar_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-avatar_3-ios.entry.js",
		"common",
		7
	],
	"./ion-avatar_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-avatar_3-md.entry.js",
		"common",
		8
	],
	"./ion-back-button-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-back-button-ios.entry.js",
		"common",
		9
	],
	"./ion-back-button-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-back-button-md.entry.js",
		"common",
		10
	],
	"./ion-backdrop-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-backdrop-ios.entry.js",
		11
	],
	"./ion-backdrop-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-backdrop-md.entry.js",
		12
	],
	"./ion-button_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-button_2-ios.entry.js",
		"common",
		13
	],
	"./ion-button_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-button_2-md.entry.js",
		"common",
		14
	],
	"./ion-card_5-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-card_5-ios.entry.js",
		"common",
		15
	],
	"./ion-card_5-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-card_5-md.entry.js",
		"common",
		16
	],
	"./ion-checkbox-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-checkbox-ios.entry.js",
		"common",
		17
	],
	"./ion-checkbox-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-checkbox-md.entry.js",
		"common",
		18
	],
	"./ion-chip-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-chip-ios.entry.js",
		"common",
		19
	],
	"./ion-chip-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-chip-md.entry.js",
		"common",
		20
	],
	"./ion-col_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-col_3.entry.js",
		21
	],
	"./ion-datetime_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-datetime_3-ios.entry.js",
		"common",
		22
	],
	"./ion-datetime_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-datetime_3-md.entry.js",
		"common",
		23
	],
	"./ion-fab_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-fab_3-ios.entry.js",
		"common",
		24
	],
	"./ion-fab_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-fab_3-md.entry.js",
		"common",
		25
	],
	"./ion-img.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-img.entry.js",
		26
	],
	"./ion-infinite-scroll_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2-ios.entry.js",
		"common",
		27
	],
	"./ion-infinite-scroll_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2-md.entry.js",
		"common",
		28
	],
	"./ion-input-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-input-ios.entry.js",
		"common",
		29
	],
	"./ion-input-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-input-md.entry.js",
		"common",
		30
	],
	"./ion-item-option_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item-option_3-ios.entry.js",
		"common",
		31
	],
	"./ion-item-option_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item-option_3-md.entry.js",
		"common",
		32
	],
	"./ion-item_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item_8-ios.entry.js",
		"common",
		33
	],
	"./ion-item_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item_8-md.entry.js",
		"common",
		34
	],
	"./ion-loading-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-loading-ios.entry.js",
		"common",
		35
	],
	"./ion-loading-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-loading-md.entry.js",
		"common",
		36
	],
	"./ion-menu_4-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-menu_4-ios.entry.js",
		"common",
		37
	],
	"./ion-menu_4-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-menu_4-md.entry.js",
		"common",
		38
	],
	"./ion-modal-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-modal-ios.entry.js",
		"common",
		39
	],
	"./ion-modal-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-modal-md.entry.js",
		"common",
		40
	],
	"./ion-nav_5.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-nav_5.entry.js",
		"common",
		41
	],
	"./ion-popover-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-popover-ios.entry.js",
		"common",
		42
	],
	"./ion-popover-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-popover-md.entry.js",
		"common",
		43
	],
	"./ion-progress-bar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-progress-bar-ios.entry.js",
		"common",
		44
	],
	"./ion-progress-bar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-progress-bar-md.entry.js",
		"common",
		45
	],
	"./ion-radio_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-radio_2-ios.entry.js",
		"common",
		46
	],
	"./ion-radio_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-radio_2-md.entry.js",
		"common",
		47
	],
	"./ion-range-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-range-ios.entry.js",
		"common",
		48
	],
	"./ion-range-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-range-md.entry.js",
		"common",
		49
	],
	"./ion-refresher_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-refresher_2-ios.entry.js",
		"common",
		50
	],
	"./ion-refresher_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-refresher_2-md.entry.js",
		"common",
		51
	],
	"./ion-reorder_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-reorder_2-ios.entry.js",
		"common",
		52
	],
	"./ion-reorder_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-reorder_2-md.entry.js",
		"common",
		53
	],
	"./ion-ripple-effect.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-ripple-effect.entry.js",
		54
	],
	"./ion-route_4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-route_4.entry.js",
		"common",
		55
	],
	"./ion-searchbar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-searchbar-ios.entry.js",
		"common",
		56
	],
	"./ion-searchbar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-searchbar-md.entry.js",
		"common",
		57
	],
	"./ion-segment_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-segment_2-ios.entry.js",
		"common",
		58
	],
	"./ion-segment_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-segment_2-md.entry.js",
		"common",
		59
	],
	"./ion-select_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-select_3-ios.entry.js",
		"common",
		60
	],
	"./ion-select_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-select_3-md.entry.js",
		"common",
		61
	],
	"./ion-slide_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-slide_2-ios.entry.js",
		62
	],
	"./ion-slide_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-slide_2-md.entry.js",
		63
	],
	"./ion-spinner.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-spinner.entry.js",
		"common",
		64
	],
	"./ion-split-pane-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-split-pane-ios.entry.js",
		65
	],
	"./ion-split-pane-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-split-pane-md.entry.js",
		66
	],
	"./ion-tab-bar_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-tab-bar_2-ios.entry.js",
		"common",
		67
	],
	"./ion-tab-bar_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-tab-bar_2-md.entry.js",
		"common",
		68
	],
	"./ion-tab_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-tab_2.entry.js",
		"common",
		69
	],
	"./ion-text.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-text.entry.js",
		"common",
		70
	],
	"./ion-textarea-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-textarea-ios.entry.js",
		"common",
		71
	],
	"./ion-textarea-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-textarea-md.entry.js",
		"common",
		72
	],
	"./ion-toast-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toast-ios.entry.js",
		"common",
		73
	],
	"./ion-toast-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toast-md.entry.js",
		"common",
		74
	],
	"./ion-toggle-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toggle-ios.entry.js",
		"common",
		75
	],
	"./ion-toggle-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toggle-md.entry.js",
		"common",
		76
	],
	"./ion-virtual-scroll.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-virtual-scroll.entry.js",
		77
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/app.component.html":
/*!**************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/app.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\n  <ion-split-pane contentId=\"mainContent\">\n\n    <ion-menu menuId=\"pages\" contentId=\"mainContent\" side=\"start\">\n     <!-- <ion-header>\n        <ion-toolbar>\n          <ion-title>Pages Menu</ion-title>\n        </ion-toolbar>\n      </ion-header>-->\n      <ion-content>\n        <ion-list  no-padding class=\"ion-no-border\">\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages\" no-padding >\n            <ion-item [routerDirection]=\"'root'\" [routerLink]=\"[p.url]\" class=\"menu-bg-color ion-no-border\">\n              <!--<ion-icon slot=\"start\" [name]=\"p.icon\"></ion-icon>-->\n              <ion-label class=\"ion-padding-start ion-padding-top ion-padding-bottom\">\n                {{p.title}}\n              </ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n        </ion-list>\n      </ion-content>\n    </ion-menu>\n\n    <ion-menu menuId=\"admin\" contentId=\"mainContent\" side=\"end\" type=\"push\"  class=\"welcome-card\">\n     <!-- <ion-header>\n        <ion-toolbar>\n          <ion-title>Admin Menu</ion-title>\n        </ion-toolbar>\n      </ion-header>-->\n      <ion-content>\n        \n        <ion-list  no-padding class=\"ion-no-border\">\n          <ion-menu-toggle menu=\"admin\" auto-hide=\"false\" *ngFor=\"let p of adminPages\" no-padding > <!--Must specify menu, otherwise will toggle menu above-->\n            <ion-item [routerDirection]=\"'root'\" [routerLink]=\"[p.url]\" class=\"menu-bg-color ion-no-border\">\n              <ion-label class=\"ion-padding-start ion-padding-top ion-padding-bottom\">\n                {{p.title}}\n              </ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n        </ion-list>\n      <div class=\"ion-padding-bottom ion-padding-start ion-padding-end\"> \n            <ion-img src=\"/assets/imgs/right-side-menu-text.png\"></ion-img>\n          </div>\n      </ion-content>\n    </ion-menu>\n\n    <ion-router-outlet id=\"mainContent\"></ion-router-outlet>\n  </ion-split-pane>\n\n</ion-app>"

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



const routes = [
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    },
    {
        path: 'home',
        loadChildren: './home/home.module#HomePageModule'
    },
    {
        path: 'list',
        loadChildren: './list/list.module#ListPageModule'
    },
    { path: 'login', loadChildren: './login/login.module#LoginPageModule' }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".menu-bg-color {\n  min-height: 81px;\n  background: url(http://netnovaz.com/nizamuddin-app/images/menu-bg-img.png) no-repeat left top, radial-gradient(#efb538, #e89116);\n  background-size: 100% 80px;\n  padding-left: 0;\n}\n\n:host {\n  --ion-item-background: transparent !important;\n}\n\n.welcome-card {\n  --ion-background-color: radial-gradient(#efb538, #e89116) !important;\n}\n\n#menu2 button.item-md {\n  min-height: 60px;\n  background: radial-gradient(#efb538, #e89116);\n  padding-left: 0;\n}\n\n#menu1 .list-md .item-block .item-inner {\n  border-bottom: 2px solid #9c6e3e;\n}\n\n#menu2 .list-md .item-block .item-inner {\n  border-bottom: 1px #9c6e3e solid;\n}\n\n#menu1 .list-md .item-block .item-inner .label-md,\n#menu2 .list-md .item-block .item-inner .label-md {\n  color: #000;\n  font-weight: bold;\n  text-overflow: none;\n  white-space: normal;\n}\n\n#menu1 .list-md .item-block .item-inner .label-md {\n  padding-left: 30px;\n}\n\n#menu2 .list-md .item-block .item-inner .label-md {\n  padding-left: 50px;\n}\n\n#menu2 .list-md .item-block .item-inner .label-md img {\n  width: 40px;\n  position: absolute;\n  left: 5px;\n  top: 10px;\n}\n\n.toolbar-background-md {\n  background-color: #6a1205;\n  color: #4a250a;\n}\n\n.toolbar-md, .toolbar-title-md {\n  padding: 10px;\n  color: #fff;\n}\n\n#menu2 .toolbar-md,\n#menu2 .toolbar-title-md {\n  padding: 0;\n  color: #4a250a;\n}\n\n.menu-inner .content-md {\n  background: radial-gradient(#efb538, #e89116);\n}\n\n.icon-left,\n.icon-right {\n  position: relative;\n  top: -15px;\n}\n\n.icon-left {\n  left: -10px;\n}\n\n.icon-right {\n  right: -10px;\n}\n\n.padding-10 {\n  padding: 10px;\n}\n\nh2.page_title {\n  margin: 15px 0;\n  font-size: 2rem;\n  font-weight: 700;\n  padding: 6px 0;\n  display: inline-block;\n  letter-spacing: -0.5px;\n  border-bottom: 3px #4a250a solid;\n  color: #4a250a;\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvQzpcXFByb2plY3RcXElvbmljXFxuaXphbXVkZGluYXBwL3NyY1xcYXBwXFxhcHAuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdCQUFBO0VBQ0EsZ0lBQUE7RUFDQSwwQkFBQTtFQUNBLGVBQUE7QUNDSjs7QURJQTtFQUNJLDZDQUFBO0FDREo7O0FESUE7RUFDSSxvRUFBQTtBQ0RKOztBRElBO0VBQ0ksZ0JBQUE7RUFDQSw2Q0FBQTtFQUNBLGVBQUE7QUNESjs7QURJQTtFQUNJLGdDQUFBO0FDREo7O0FESUE7RUFDSSxnQ0FBQTtBQ0RKOztBREdBOztFQUVJLFdBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7QUNBSjs7QURHQTtFQUNJLGtCQUFBO0FDQUo7O0FERUE7RUFDSSxrQkFBQTtBQ0NKOztBREdBO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFNBQUE7QUNBSjs7QURFQTtFQUNJLHlCQUFBO0VBQ0EsY0FBQTtBQ0NKOztBREVBO0VBQ0ksYUFBQTtFQUNBLFdBQUE7QUNDSjs7QURFQTs7RUFFSSxVQUFBO0VBQ0EsY0FBQTtBQ0NKOztBRENBO0VBQ0ksNkNBQUE7QUNFSjs7QURBQTs7RUFFSSxrQkFBQTtFQUNBLFVBQUE7QUNHSjs7QUREQTtFQUNJLFdBQUE7QUNJSjs7QUREQTtFQUNJLFlBQUE7QUNJSjs7QUREQTtFQUNJLGFBQUE7QUNJSjs7QURGQTtFQUNJLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtFQUNBLGdDQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QUNLSiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tZW51LWJnLWNvbG9yIHtcclxuICAgIG1pbi1oZWlnaHQ6IDgxcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiB1cmwoaHR0cDovL25ldG5vdmF6LmNvbS9uaXphbXVkZGluLWFwcC9pbWFnZXMvbWVudS1iZy1pbWcucG5nKSBuby1yZXBlYXQgbGVmdCB0b3AsIHJhZGlhbC1ncmFkaWVudCgjZWZiNTM4LCAjZTg5MTE2KTtcclxuICAgIGJhY2tncm91bmQtc2l6ZTogMTAwJSA4MHB4O1xyXG4gICAgcGFkZGluZy1sZWZ0OiAwO1xyXG5cclxuXHJcbiAgXHJcbn1cclxuOmhvc3Qge1xyXG4gICAgLS1pb24taXRlbS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ud2VsY29tZS1jYXJkIHtcclxuICAgIC0taW9uLWJhY2tncm91bmQtY29sb3I6IHJhZGlhbC1ncmFkaWVudCgjZWZiNTM4LCAjZTg5MTE2KSAhaW1wb3J0YW50O1xyXG4gIH1cclxuXHJcbiNtZW51MiBidXR0b24uaXRlbS1tZHtcclxuICAgIG1pbi1oZWlnaHQ6IDYwcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiAgcmFkaWFsLWdyYWRpZW50KCNlZmI1MzgsICNlODkxMTYpO1xyXG4gICAgcGFkZGluZy1sZWZ0OiAwO1xyXG59XHJcblxyXG4jbWVudTEgLmxpc3QtbWQgLml0ZW0tYmxvY2sgLml0ZW0taW5uZXJ7XHJcbiAgICBib3JkZXItYm90dG9tOiAycHggc29saWQgIzljNmUzZTtcclxufVxyXG5cclxuI21lbnUyIC5saXN0LW1kIC5pdGVtLWJsb2NrIC5pdGVtLWlubmVye1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4ICM5YzZlM2Ugc29saWQ7XHJcbn1cclxuI21lbnUxIC5saXN0LW1kIC5pdGVtLWJsb2NrIC5pdGVtLWlubmVyIC5sYWJlbC1tZCxcclxuI21lbnUyIC5saXN0LW1kIC5pdGVtLWJsb2NrIC5pdGVtLWlubmVyIC5sYWJlbC1tZHtcclxuICAgIGNvbG9yOiAjMDAwO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICB0ZXh0LW92ZXJmbG93OiBub25lO1xyXG4gICAgd2hpdGUtc3BhY2U6IG5vcm1hbDtcclxufVxyXG5cclxuI21lbnUxIC5saXN0LW1kIC5pdGVtLWJsb2NrIC5pdGVtLWlubmVyIC5sYWJlbC1tZHtcclxuICAgIHBhZGRpbmctbGVmdDogMzBweDtcclxufVxyXG4jbWVudTIgLmxpc3QtbWQgLml0ZW0tYmxvY2sgLml0ZW0taW5uZXIgLmxhYmVsLW1ke1xyXG4gICAgcGFkZGluZy1sZWZ0OiA1MHB4O1xyXG59XHJcblxyXG5cclxuI21lbnUyIC5saXN0LW1kIC5pdGVtLWJsb2NrIC5pdGVtLWlubmVyIC5sYWJlbC1tZCBpbWcge1xyXG4gICAgd2lkdGg6IDQwcHg7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBsZWZ0OiA1cHg7XHJcbiAgICB0b3A6IDEwcHg7XHJcbn1cclxuLnRvb2xiYXItYmFja2dyb3VuZC1tZHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM2YTEyMDU7XHJcbiAgICBjb2xvcjogIzRhMjUwYTtcclxufVxyXG5cclxuLnRvb2xiYXItbWQsIC50b29sYmFyLXRpdGxlLW1ke1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG59XHJcblxyXG4jbWVudTIgLnRvb2xiYXItbWQsXHJcbiNtZW51MiAudG9vbGJhci10aXRsZS1tZHtcclxuICAgIHBhZGRpbmc6IDA7XHJcbiAgICBjb2xvcjogIzRhMjUwYTtcclxufVxyXG4ubWVudS1pbm5lciAuY29udGVudC1tZCB7XHJcbiAgICBiYWNrZ3JvdW5kOiByYWRpYWwtZ3JhZGllbnQoI2VmYjUzOCwgI2U4OTExNik7XHJcbn1cclxuLmljb24tbGVmdCwgXHJcbi5pY29uLXJpZ2h0e1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlOyAgICBcclxuICAgIHRvcDogLTE1cHg7XHJcbn1cclxuLmljb24tbGVmdHtcclxuICAgIGxlZnQ6IC0xMHB4O1xyXG59XHJcblxyXG4uaWNvbi1yaWdodHtcclxuICAgIHJpZ2h0OiAtMTBweDtcclxufVxyXG5cclxuLnBhZGRpbmctMTB7XHJcbiAgICBwYWRkaW5nOjEwcHg7XHJcbn1cclxuaDIucGFnZV90aXRsZSB7XHJcbiAgICBtYXJnaW46IDE1cHggMDtcclxuICAgIGZvbnQtc2l6ZTogMnJlbTtcclxuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICBwYWRkaW5nOiA2cHggMDtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIGxldHRlci1zcGFjaW5nOiAtMC41cHg7XHJcbiAgICBib3JkZXItYm90dG9tOiAzcHggIzRhMjUwYSBzb2xpZDtcclxuICAgIGNvbG9yOiAjNGEyNTBhO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbn0iLCIubWVudS1iZy1jb2xvciB7XG4gIG1pbi1oZWlnaHQ6IDgxcHg7XG4gIGJhY2tncm91bmQ6IHVybChodHRwOi8vbmV0bm92YXouY29tL25pemFtdWRkaW4tYXBwL2ltYWdlcy9tZW51LWJnLWltZy5wbmcpIG5vLXJlcGVhdCBsZWZ0IHRvcCwgcmFkaWFsLWdyYWRpZW50KCNlZmI1MzgsICNlODkxMTYpO1xuICBiYWNrZ3JvdW5kLXNpemU6IDEwMCUgODBweDtcbiAgcGFkZGluZy1sZWZ0OiAwO1xufVxuXG46aG9zdCB7XG4gIC0taW9uLWl0ZW0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbn1cblxuLndlbGNvbWUtY2FyZCB7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IHJhZGlhbC1ncmFkaWVudCgjZWZiNTM4LCAjZTg5MTE2KSAhaW1wb3J0YW50O1xufVxuXG4jbWVudTIgYnV0dG9uLml0ZW0tbWQge1xuICBtaW4taGVpZ2h0OiA2MHB4O1xuICBiYWNrZ3JvdW5kOiByYWRpYWwtZ3JhZGllbnQoI2VmYjUzOCwgI2U4OTExNik7XG4gIHBhZGRpbmctbGVmdDogMDtcbn1cblxuI21lbnUxIC5saXN0LW1kIC5pdGVtLWJsb2NrIC5pdGVtLWlubmVyIHtcbiAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkICM5YzZlM2U7XG59XG5cbiNtZW51MiAubGlzdC1tZCAuaXRlbS1ibG9jayAuaXRlbS1pbm5lciB7XG4gIGJvcmRlci1ib3R0b206IDFweCAjOWM2ZTNlIHNvbGlkO1xufVxuXG4jbWVudTEgLmxpc3QtbWQgLml0ZW0tYmxvY2sgLml0ZW0taW5uZXIgLmxhYmVsLW1kLFxuI21lbnUyIC5saXN0LW1kIC5pdGVtLWJsb2NrIC5pdGVtLWlubmVyIC5sYWJlbC1tZCB7XG4gIGNvbG9yOiAjMDAwO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgdGV4dC1vdmVyZmxvdzogbm9uZTtcbiAgd2hpdGUtc3BhY2U6IG5vcm1hbDtcbn1cblxuI21lbnUxIC5saXN0LW1kIC5pdGVtLWJsb2NrIC5pdGVtLWlubmVyIC5sYWJlbC1tZCB7XG4gIHBhZGRpbmctbGVmdDogMzBweDtcbn1cblxuI21lbnUyIC5saXN0LW1kIC5pdGVtLWJsb2NrIC5pdGVtLWlubmVyIC5sYWJlbC1tZCB7XG4gIHBhZGRpbmctbGVmdDogNTBweDtcbn1cblxuI21lbnUyIC5saXN0LW1kIC5pdGVtLWJsb2NrIC5pdGVtLWlubmVyIC5sYWJlbC1tZCBpbWcge1xuICB3aWR0aDogNDBweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiA1cHg7XG4gIHRvcDogMTBweDtcbn1cblxuLnRvb2xiYXItYmFja2dyb3VuZC1tZCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICM2YTEyMDU7XG4gIGNvbG9yOiAjNGEyNTBhO1xufVxuXG4udG9vbGJhci1tZCwgLnRvb2xiYXItdGl0bGUtbWQge1xuICBwYWRkaW5nOiAxMHB4O1xuICBjb2xvcjogI2ZmZjtcbn1cblxuI21lbnUyIC50b29sYmFyLW1kLFxuI21lbnUyIC50b29sYmFyLXRpdGxlLW1kIHtcbiAgcGFkZGluZzogMDtcbiAgY29sb3I6ICM0YTI1MGE7XG59XG5cbi5tZW51LWlubmVyIC5jb250ZW50LW1kIHtcbiAgYmFja2dyb3VuZDogcmFkaWFsLWdyYWRpZW50KCNlZmI1MzgsICNlODkxMTYpO1xufVxuXG4uaWNvbi1sZWZ0LFxuLmljb24tcmlnaHQge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHRvcDogLTE1cHg7XG59XG5cbi5pY29uLWxlZnQge1xuICBsZWZ0OiAtMTBweDtcbn1cblxuLmljb24tcmlnaHQge1xuICByaWdodDogLTEwcHg7XG59XG5cbi5wYWRkaW5nLTEwIHtcbiAgcGFkZGluZzogMTBweDtcbn1cblxuaDIucGFnZV90aXRsZSB7XG4gIG1hcmdpbjogMTVweCAwO1xuICBmb250LXNpemU6IDJyZW07XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIHBhZGRpbmc6IDZweCAwO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIGxldHRlci1zcGFjaW5nOiAtMC41cHg7XG4gIGJvcmRlci1ib3R0b206IDNweCAjNGEyNTBhIHNvbGlkO1xuICBjb2xvcjogIzRhMjUwYTtcbiAgd2lkdGg6IDEwMCU7XG59Il19 */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");





let AppComponent = class AppComponent {
    constructor(platform, splashScreen, statusBar) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.appPages = [
            { title: 'Home', url: '/home', icon: 'home' },
            { title: 'Hazrat Nizamuddin Aulia (R.A.)', url: '/home', icon: 'home' },
            { title: 'Hazrat Amir Khusrau (R.A.)', url: '/home', icon: 'home' },
            { title: 'Islam & Sufism', url: '/home', icon: 'home' },
            { title: 'Beliefs', url: '/home', icon: 'home' },
            { title: 'Shajrah (Spiritual Chain)', url: '/home', icon: 'home' },
            { title: 'Online Offerings', url: '/home', icon: 'home' },
            { title: 'Donation', url: '/home', icon: 'home' },
            { title: 'Projects', url: '/home', icon: 'home' },
            { title: 'Photos', url: '/home', icon: 'home' },
            { title: 'Videos', url: '/home', icon: 'home' },
            { title: 'Contact', url: '/home', icon: 'home' }
        ];
        this.adminPages = [
            { src: "images/icons/user-menu-web-icon.png", alt: "web icon", title: "Visit Our Website", url: "http://nizamuddinaulia.org/" },
            { src: "images/icons/book-pdf-icon.png", alt: "Books and PDF", title: "Recitation Wazifa", url: "http://netnovaz.com/nizamuddin-app/books-and-pdf/Wazifa.pdf" },
            { src: "images/icons/user-menu-fb-icon.png", alt: "fb icon", title: "Like Us on Facebook", url: "https://www.facebook.com/dargahnizamuddinaulia/" },
            { src: "images/icons/user-menu-tw-icon.png", alt: "twitter icon", title: "Follow us on Twitter", url: "https://twitter.com/sufi_centre" },
            { src: "images/icons/user-menu-insta-icon.png", alt: "instagram Icon", title: "Follow us on Instagram", url: "https://www.instagram.com/dargahnizamuddinaulia/" },
            { src: "images/icons/user-menu-yt-icon.png", alt: "youtube icon", title: "Subscribe us on Youtube", url: "https://www.youtube.com/channel/UCreOlP89ZAOCe-micSrA5qA" }
        ];
        this.initializeApp();
    }
    initializeApp() {
        this.platform.ready().then(() => {
            this.statusBar.styleDefault();
            this.splashScreen.hide();
        });
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"] },
    { type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__["SplashScreen"] },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__["StatusBar"] }
];
AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-root',
        template: __webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/index.js!./src/app/app.component.html"),
        styles: [__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"],
        _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__["SplashScreen"],
        _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__["StatusBar"]])
], AppComponent);



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");










let AppModule = class AppModule {
};
AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
        entryComponents: [],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpClientModule"]
        ],
        providers: [
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"],
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] }
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
    })
], AppModule);



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.log(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Project\Ionic\nizamuddinapp\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map